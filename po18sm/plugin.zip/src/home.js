function execute() {
    return Response.success([
        {title: "Ảo tưởng", input: "https://www.po18sm.com/list/1", script: "gen.js"},
        {title: "Tu chân", input: "https://www.po18sm.com/list/2", script: "gen.js"},
        {title: "Đô thị", input: "https://www.po18sm.com/list/3", script: "gen.js"}
    ]);
}
